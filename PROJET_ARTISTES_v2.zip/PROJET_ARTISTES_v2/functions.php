<?php

function display_artiste(array $artiste) : string
{
    $recipe_content = '';

    if ($artiste['active']) {
        $artiste_content .= '<h3>' . $artiste['name'] . '</h3>';

    }
    
    return $artiste_content;
}


function get_artistes(array $artistes, int $limit) : array
{
    $valid_artistes = [];
    $counter = 0;

    foreach($artistes as $artiste) {
        if ($counter == $limit) {
            return $valid_artistes;
        }

        $valid_artistes[] = $artiste;
        $counter++;
    }

    return $artistes;
}